# Interaction patterns

## Dense workspaces and comparisons

Choose the user decision first: scan, compare, find an exception, or act on a record. Keep active scope, filters and units close to their result. Make charts answer a specific question with labeled axes, useful scale and a text or table equivalent. Give the stronger visual treatment to the data the user acts on. Use context such as a trend or total to guide users toward a relevant record or control. When a cue repeats, use the concise version close to the affected group.

Use semantic tables when row/column relationships matter. Put the lookup label where scanning starts and the first decisive value nearby. Compare numeric values on aligned baselines. Use modest row separators, restrained exception cues and an action with a clear target. Reserve space for expansion, longer data and new states.

At narrow widths prioritize visible labels and decisive values. Keep table scrolling internal when the axes matter and show that more columns are available. If needed make the row heading sticky and the region keyboard-accessible. For record-by-record work, adapt a row to a compact labeled stack. Keep the identity, decisive status or value, and row action close. Design the default, filtered and expanded views around the same alignment or order so the user can see what changed. Keep a way to reach lower-priority data.

## Navigation and controls

Use navigation patterns supported by the amount of content and the number of real destinations. Preserve current location and main destinations when converting a sidebar, menu or secondary navigation to a disclosure. Keep enough context to identify the record and return to the same list or reading position when revealing details. Test keyboard opening, dismissal and focus restoration for dialogs and menus. Close or reconcile overlays when navigation changes context.

Use real buttons for actions and links for destinations. Keep native inputs where they meet the interaction, with clear labels and visible hover, focus and state cues. Provide an adequately sized pointer target or spacing, especially on touch. Use a larger hit area than the visible icon when needed. Preserve visible focus in the design system.

## Forms and states

Group the minimum fields needed at each step. Show meaningful progress and give a clear next action. Preserve inputs on navigation and validation. Link each error to its field, move focus when appropriate and let a user correct one error without losing the rest of the work. When focus and error overlap, make focus location and the error message clear with a coordinated treatment. Keep progress secondary to the active step and rebalance the screen when the task is complete. Use explicit review or confirmation for important submissions, with an actionable success state or next step.

For async data, scope feedback to the affected region. Show progress, a useful empty state, error recovery and a reason when a necessary action is disabled. Make changed state perceivable without color alone. Guard against duplicate submissions when the underlying operation needs it.
