# UX Designer

Use this skill to build, refine, critique or specify an interface. It applies the feature-first design and visual systems of Adam Wathan and Steve Schoger to working product UI. Start with the [skill entrypoint](SKILL.md) and read the reference that matches the task. [Refactoring UI](https://refactoringui.com/)

The CSS and framework assets are optional examples. Projects updating a direct import of the original CSS should apply `.ux-prototype` to the area meant to receive prototype styling, set intentional page and component styles, and check any overridden status colors. This release scopes prototype styling and removes the universal margin and padding reset. It also matches the requested output, so work that needs a full report should ask for a spec. See [asset integration and handoff](references/templates.md).

The [browser benchmark](../../benchmarks/ux-designer/README.md) records its fixed briefs, design review rubric and rendered comparisons.
